import React from 'react';
import './App.css';
import Devices from './dashboard/Devices'



function App() {
  return (
    <div className="App">
      <Devices/>
    </div>
  );
}

export default App;
