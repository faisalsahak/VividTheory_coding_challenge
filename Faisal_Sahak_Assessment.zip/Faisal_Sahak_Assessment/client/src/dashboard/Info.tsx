const Info = ()=>{
	return(
		<div>
			<p className='text'>
			 The chart shows a visualization of the electricity consumption in the house for a particular device.
			 The x-axis shows the time of day along with the hour and minute that particular device was consuming electricity.
			 The y-axis shows the wattage consumed during a particular minute on a given day. The dropdown menu "Device" has all
			 the devices in the house that are being monitored, clicking each device will show a chart of how much electricity it
			 is consuming. When you select a device there is a 1-3 seconds delay as the front-end communicates with the back-end
			 which then sends a reqeust to a database.
			 </p>
		 </div>


	)
}

export default Info