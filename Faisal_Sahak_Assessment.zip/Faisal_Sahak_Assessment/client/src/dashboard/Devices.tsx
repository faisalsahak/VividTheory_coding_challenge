import React, { useEffect, useState } from "react";
import Chart from './Chart'
import Info from './Info'
import "./Devices.css"
var axios = require("axios").default;



let device: {Device_ID: string; Device_Name: string, Device_Location:string } = {
  Device_ID: "",
  Device_Name: "",
  Device_Location:''
};
const Devices: React.FC = () => {
  const [data, setData] = useState([device]);
  const [deviceId, setDeviceId] = useState("");
  const [pageLoaded, setPageLoaded] = useState(false);

  useEffect(() => {
    async function fetchMyAPI() {// async function which calls the back-end to retrive the information for all the devices
      try{
	      const response = await axios.get("http://localhost:8080/alldevices");  // will hold the object that is sent back from the server
	      setData(response.data);// sets the information sent back from the server in the allData for later use
	      // once we have the onformation from the server the pageLoaded variable is set to true, 
		    //which then allows us to plot the data into a chart if this step is not implemented
		    //then the we will be displaying the chart without any data which will then throw an error
	      setPageLoaded(true);
	      load("6fc1f883")// renders a hardcoded device to the screen
	    }catch(err){
	    	// console.error(err)
	    }
    }
    fetchMyAPI();
  }, []);

  function load(str:string){ // this function loads a hardcoded device's chart to the screen
  	setDeviceId(str)
  }

  const handleChange = (e: React.ChangeEvent<any>) => { // function runs everytime we change the selection of devices from the drop down menu
    setDeviceId(String(e.target.value));
  };
  return (
      <div>
	  	{!pageLoaded && <div>Retrieving Data From Server</div> }
	   	{pageLoaded && (
	   		<div>
		        <div>
		          <h3>Select a Device</h3>
		        </div>
		        <div>
		          <form>
		            <label>Device: </label>
		            <select value={deviceId} onChange={handleChange}>
		              {data.map((item, index) => {
		                return (
		                  <option key={index} value={item.Device_ID}>{item.Device_Name} {item.Device_Location}</option>
		                )})};
		            </select>
		          </form>
		        </div>
		        <section className='chart_info'>
			        <Chart deviceId={deviceId} />
			        <Info />
			    </section>
			</div>
	    )}
     </div>
    )
};

export default Devices;
