import React, { useState,useEffect } from 'react';
import {LineChart, XAxis,YAxis, CartesianGrid,Line, Tooltip,ResponsiveContainer} from 'recharts'
import moment from 'moment'
var axios = require("axios");



let deviceInfo: { DateTime: string; Wattage: string}={
	DateTime:'',
	Wattage:''
}

const Chart: React.FC<{deviceId:string}> =({deviceId})=>{
	const [allData, setAllData] = useState([deviceInfo]);
	const [pageLoaded, setPageLoaded] = useState(false)
	// let pageLoaded = false

	useEffect(() => {
    	async function fetchMyAPI() { // async function which calls the back-end to retrive the information based on the deviceId
    		try{
		       	const response = await axios.get(`http://localhost:8080/data/${deviceId}`); // will hold the object that is sent back from the server
		       	convertDateTime(response)
		       	console.log(response.data)
		       	setAllData(response.data) // sets the information sent back from the server in the allData for later use
		      	// once we have the onformation from the server the pageLoaded variable is set to true, 
		      	//which then allows us to plot the data into a chart if this step is not implemented
		      	//then the we will be displaying the chart without any data which will then throw an error
		      	setPageLoaded(true)
		      	// pageLoaded = true
		    }catch(err){ 
		    	// console.error(err)
		    }
    	}
    	fetchMyAPI();
	}, [deviceId]);


	function convertDateTime(d:Object){ // takes in an object and converts it to the number of milliseconds since the unix epoch
		d.data.forEach((date: {DateTime: moment.MomentInput}) => {
		  date.DateTime = moment(date.DateTime).valueOf()
		})
	}

	// this calculates the highest amount of watt consumed, which is being used to render the chart
	//from 0 to highest amount of wattage consumed
	const maxItem = (arr)=>{ 
		let max = -Number.MAX_VALUE;
		arr.forEach(function (item) {
		    max = Math.max(max, item.Wattage);
		});
		return max
	}

	return ( 
   		<div>
   			{!pageLoaded && <h3>Chart is Loading</h3>}
   			{pageLoaded &&(
   				<>
   				<h2>Device Power Consumption Over Time</h2>
				<ResponsiveContainer width="100%" height={500}>
		          <LineChart label = {{value: "Device Power Consumption Over Time"}} data={allData}>
		            <Line type="monotone" dataKey="Wattage" stroke="black" strokeWidth={1} dot={false}/>
		            <CartesianGrid strokeDasharray="5 3" />
		            <XAxis dataKey="DateTime" domain={[allData[0].DateTime, allData[allData.length - 1].DateTime]} 
		            	scale="time" type="number" height={50} tickFormatter={(date)=> moment(date).format("MMMM Do HH:mm")}
		            	label={{ value: 'Time', position: 'insideBottom'}}/>
		            <YAxis datakey={"Wattage"} type="number" domain={[0,maxItem(allData)+50]}
		              label={{ value: 'Wattage', angle: -90, position: 'insideLeft' }}/>
		            <Tooltip labelFormatter={(date)=> moment(date).format("MMMM Do HH:mm")} />
		          </LineChart>
    			</ResponsiveContainer>
    			</>
			)}
		</div>
	)
}

export default Chart